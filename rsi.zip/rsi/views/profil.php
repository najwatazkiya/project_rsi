<?php include "views/template/sidebar.php"; ?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Profil</title>

    <style>
        /* ===== GLOBAL ===== */
        body {
            font-family: "Poppins", sans-serif;
            background: #f7f7f7;
            margin: 0;
        }

        /* ===== AREA KONTEN (menghindari tertutup sidebar) ===== */
        .main {
            padding: 40px;
            margin-left: 260px; /* ukuran sidebar */
        }

        /* ===== HEADER ===== */
        .header-title {
            margin-bottom: 20px;
        }

        .header-title h1 {
            margin: 0;
            font-size: 28px;
            color: #1f3558;
        }

        .back-link {
            text-decoration: none;
            color: #1f3558;
            font-size: 14px;
        }

        /* ===== WRAPPER CARD ===== */
        .profile-wrapper {
            display: flex;
            justify-content: center;
            width: 100%;
            margin-top: 20px;
        }

        /* ===== CARD ===== */
        .profile-card {
            background: #ffffff;
            width: 650px;
            padding: 35px 40px;
            border-radius: 18px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
        }

        /* Foto + nama */
        .profile-top {
            text-align: center;
        }

        .profile-photo {
            width: 95px;
            height: 95px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #e5e5e5;
        }

        .profile-name {
            margin-top: 12px;
            color: #1f3558;
            font-size: 22px;
            font-weight: 600;
        }

        .divider {
            margin: 20px 0;
            border: none;
            height: 1px;
            background: #e0e0e0;
        }

        .section-title {
            text-align: center;
            margin-bottom: 25px;
            font-size: 20px;
            font-weight: 600;
            color: #1f3558;
        }

        /* Form */
        .form-group {
            margin-bottom: 18px;
        }

        .form-group label {
            font-size: 14px;
            margin-bottom: 6px;
            display: block;
            color: #444;
        }

        .form-group input[type="text"],
        .form-group input[type="email"],
        .form-group input[type="password"] {
            width: 100%;
            padding: 12px;
            border-radius: 8px;
            border: 1px solid #ddd;
            background: #f3f3f3;
        }

        .update-btn {
            width: 100%;
            margin-top: 15px;
            padding: 14px;
            border: none;
            background: #1f3558;
            color: white;
            font-size: 15px;
            border-radius: 10px;
            cursor: pointer;
            transition: 0.2s;
        }

        .update-btn:hover {
            background: #162742;
        }
    </style>
</head>

<body>

<div class="main">

    <!-- Header Judul -->
    <div class="header-title">
        <a href="javascript:history.back()" class="back-link">← Kembali</a>
        <h1>Profil</h1>
    </div>

    <div class="profile-wrapper">

        <div class="profile-card">

            <!-- Bagian Foto & Nama -->
            <div class="profile-top">
                <img 
                    src="<?= $user['photo'] ? $user['photo'] : 'assets/default_profile.png' ?>" 
                    class="profile-photo" 
                    alt="Foto Profil"
                >
                <h2 class="profile-name"><?= htmlspecialchars($user['nama']) ?></h2>
            </div>

            <hr class="divider">

            <h3 class="section-title">Profil Saya</h3>

            <!-- Form Update Foto
